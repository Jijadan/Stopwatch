import java.awt.Color;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author jijadan
 */
public class Inicio extends javax.swing.JFrame {

    public Inicio() {
        initComponents();
        Image icon = Toolkit.getDefaultToolkit().getImage(getClass().getResource("/Imagenes/a.png"));
        setIconImage(icon);
        setVisible(true);
        tiempo = new Timer(1, acciones);
        this.setLocationRelativeTo(null);
        jBtnInicio.requestFocus();
    }

    private Timer tiempo;
    private int dias;
    private int horas;
    private int minutos;
    private int segundos;
    private int milisegundos;

    private ActionListener acciones = new ActionListener() {

        @Override
        public void actionPerformed(ActionEvent ae) {
            milisegundos++;

            if (milisegundos == 100) {
                milisegundos = 0;
                segundos++;
            }
            if (segundos == 60) {
                segundos = 0;
                minutos++;
            }
            if (minutos == 60) {
                minutos = 0;
                horas++;
            }
            if (horas == 24) {
                horas = 0;
                dias++;
            }
            actualizar();
        }

    };

    private void actualizar() {
        String imprimirTiempo = (dias <= 9 ? "0" : "") + dias + ":" + (horas <= 9 ? "0" : "") + horas + ":" + (minutos <= 9 ? "0" : "") + minutos + ":" + (segundos <= 9 ? "0" : "") + segundos + ":" + (milisegundos <= 9 ? "0" : "") + milisegundos;
        jTxtTiempo.setText(imprimirTiempo);
    }

    private void reiniciar() {
        dias = 00;
        horas = 00;
        minutos = 00;
        segundos = 00;
        milisegundos = 00;
        actualizar();
        jTxtTiempo.setText("0" + dias + ":" + "0" + horas + ":" + "0" + minutos + ":" + "0" + segundos + ":" + "0" + milisegundos);
    }

    public void tabla() {
        String[] titulos = {"Vuelta"};
        String[] lap = new String[1];
        String sql = "select * from cronometro";
        DefaultTableModel model = new DefaultTableModel();
        model = new DefaultTableModel(null, titulos);

        conectar c = new conectar();
        Connection cn = c.coneccion();

        try {
            Statement estado = cn.createStatement();
            ResultSet resultado = estado.executeQuery(sql);

            while (resultado.next()) {
                lap[0] = resultado.getString("Tiempo");
                
                model.addRow(lap);
            }

            jTabla.setModel(model);

            cn.close();
        } catch (SQLException e) {
           }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTxtTiempo = new javax.swing.JTextField();
        jBtnReiniciar = new javax.swing.JButton();
        jBtnInicio = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jToggleBtnPausa = new javax.swing.JToggleButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTabla = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Cronómetro");
        setAlwaysOnTop(true);
        setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTxtTiempo.setEditable(false);
        jTxtTiempo.setBackground(new java.awt.Color(255, 255, 255));
        jTxtTiempo.setFont(new java.awt.Font("Monospaced", 0, 36)); // NOI18N
        jTxtTiempo.setForeground(new java.awt.Color(204, 153, 0));
        jTxtTiempo.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTxtTiempo.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Tiempo", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.ABOVE_TOP, new java.awt.Font("Tahoma", 0, 14))); // NOI18N
        jTxtTiempo.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        getContentPane().add(jTxtTiempo, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 11, 390, 130));

        jBtnReiniciar.setBackground(new java.awt.Color(255, 255, 255));
        jBtnReiniciar.setFont(new java.awt.Font("MS Reference Sans Serif", 0, 17)); // NOI18N
        jBtnReiniciar.setForeground(new java.awt.Color(255, 0, 204));
        jBtnReiniciar.setText("Reiniciar");
        jBtnReiniciar.setToolTipText("Nota: si sale del programa sin reiniciar las vueltas, se almacenarán para la siguiente vez");
        jBtnReiniciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnReiniciarActionPerformed(evt);
            }
        });
        getContentPane().add(jBtnReiniciar, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 150, 110, -1));

        jBtnInicio.setFont(new java.awt.Font("MS Reference Sans Serif", 1, 18)); // NOI18N
        jBtnInicio.setForeground(new java.awt.Color(0, 153, 0));
        jBtnInicio.setText("Iniciar");
        jBtnInicio.setOpaque(false);
        jBtnInicio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jBtnInicioActionPerformed(evt);
            }
        });
        getContentPane().add(jBtnInicio, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 160, 30));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 14)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Developed by @Jijadan");
        jLabel2.setEnabled(false);
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 380, -1, -1));

        jToggleBtnPausa.setFont(new java.awt.Font("MS Reference Sans Serif", 0, 15)); // NOI18N
        jToggleBtnPausa.setForeground(new java.awt.Color(0, 153, 153));
        jToggleBtnPausa.setText("Pausa");
        jToggleBtnPausa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleBtnPausaActionPerformed(evt);
            }
        });
        getContentPane().add(jToggleBtnPausa, new org.netbeans.lib.awtextra.AbsoluteConstraints(173, 150, 110, -1));

        jTabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTabla);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 190, 320, 180));

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("      ");
        jLabel1.setOpaque(true);
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -16, 410, 420));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jBtnReiniciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnReiniciarActionPerformed
        if (tiempo.isRunning()) {
            tiempo.stop();
            reiniciar();
            jBtnInicio.setText("Iniciar");
            jBtnInicio.setForeground(Color.green);
            jBtnInicio.setEnabled(true);
            jToggleBtnPausa.setSelected(false);

            conectar o = new conectar();
            Connection cn = o.coneccion();
            String sql = "delete from cronometro";
            try {
                Statement estado = cn.createStatement();
                ResultSet resultado = estado.executeQuery(sql);
                cn.close();
            } catch (SQLException ex) {
                } 
            tabla();
        } else{
            tiempo.stop();
            reiniciar();
            jBtnInicio.setText("Iniciar");
            jBtnInicio.setForeground(Color.green);
            jBtnInicio.setEnabled(true);
            jToggleBtnPausa.setSelected(false);
            
            conectar o = new conectar();
            Connection cn = o.coneccion();
            String sql = "delete from cronometro";
            try {
                Statement estado = cn.createStatement();
                ResultSet resultado = estado.executeQuery(sql);
                cn.close();
            } catch (SQLException ex) {
                }
            tabla();
        }
    }//GEN-LAST:event_jBtnReiniciarActionPerformed

    private void jBtnInicioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jBtnInicioActionPerformed
    tiempo.start();
        jBtnInicio.setText("Vuelta");
            conectar o = new conectar();
            Connection cn = o.coneccion();
            String sql = "insert into cronometro(Tiempo) values ('" + jTxtTiempo.getText() + "')";
            try {
                Statement estado = cn.createStatement();
                ResultSet resultado = estado.executeQuery(sql);
                cn.close();
            } catch (SQLException ex) {
                }
            tabla();
    }//GEN-LAST:event_jBtnInicioActionPerformed

    private void jToggleBtnPausaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleBtnPausaActionPerformed
        if (jToggleBtnPausa.isSelected()) {
            tiempo.stop();
            jToggleBtnPausa.setText("Continuar");
            jToggleBtnPausa.setForeground(Color.red);
            jBtnInicio.setEnabled(false);
        } else {
            tiempo.start();
            jToggleBtnPausa.setText("Pausa");
            jToggleBtnPausa.setForeground(Color.cyan);
            jBtnInicio.setEnabled(true);
           
        }
    }//GEN-LAST:event_jToggleBtnPausaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Inicio.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Inicio().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jBtnInicio;
    private javax.swing.JButton jBtnReiniciar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTabla;
    private javax.swing.JToggleButton jToggleBtnPausa;
    private javax.swing.JTextField jTxtTiempo;
    // End of variables declaration//GEN-END:variables
//AUTOHOR jijadan for more info jijadan@gmail.com
//Autor jijadan para más información jijadan@gmail.com
    /*if (jToggleBtnInicio.isSelected()) {
            tiempo.start();
            jToggleBtnInicio.setText("Pausa");
            jToggleBtnInicio.setForeground(Color.ORANGE);

             
            
        } else {
            //tiempo.stop();
            jToggleBtnInicio.setText("Continuar");
            jToggleBtnInicio.setForeground(Color.cyan);
            
           
        }*/
}
