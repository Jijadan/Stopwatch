import java.sql.*;
import javax.swing.JOptionPane;
 
public class conectar {
 
    Connection conectar = null;
    
   public Connection coneccion(){
       try {
           
           Class.forName("org.sqlite.JDBC");
          
           conectar = DriverManager.getConnection("jdbc:sqlite:tiempo.db");//_backup
          
       } catch (ClassNotFoundException | SQLException e) {
           
           JOptionPane.showMessageDialog(null, "Error de Conexion inicial: " + e);
           
       }
       return conectar;
   }
}
